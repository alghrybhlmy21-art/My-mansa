import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Play, Pause, Trash2, Plus, GripVertical, Sparkles, Type, Music, Images, SlidersHorizontal, Download, Film, Save, FolderOpen, X, Check, AlertCircle, Volume2, VolumeX, RotateCcw, Clock, Wand2, AlertTriangle, RefreshCw } from 'lucide-react';

type Slide = { id:string; title:string; color:string; color2:string; pattern:string };
type Settings = { duration:number; aspect:'16:9'|'9:16'|'1:1'; quality:'720p'|'1080p'; transition:'fade'|'slide'|'zoom'|'none'; speed:number; title:string; subtitle:string; pos:'top'|'center'|'bottom'; textColor:string; fontSize:number; filter:'none'|'warm'|'cool'|'bw'|'vintage'; watermark:string; showWatermark:boolean; muted:boolean };

const PALETTES = [
  {color:'#7c3aed', color2:'#ec4899', label:'بنفسجي × وردي'},
  {color:'#0ea5e9', color2:'#7c3aed', label:'أزرق × بنفسجي'},
  {color:'#f59e0b', color2:'#ef4444', label:'برتقالي × أحمر'},
  {color:'#059669', color2:'#0ea5e9', label:'أخضر × أزرق'},
  {color:'#111827', color2:'#7c3aed', label:'داكن × بنفسجي'},
  {color:'#db2777', color2:'#f59e0b', label:'وردي × ذهبي'},
];
const FILTERS: {id:Settings['filter']; label:string; desc:string; css:string}[] = [
  {id:'none', label:'عادي', desc:'بدون تعديل', css:'none'},
  {id:'warm', label:'دافئ', desc:'ألوان ذهبية دافئة', css:'saturate(1.35) sepia(0.22) contrast(1.05)'},
  {id:'cool', label:'بارد', desc:'درجات زرقاء هادئة', css:'saturate(1.15) hue-rotate(185deg) brightness(1.05)'},
  {id:'bw', label:'أبيض وأسود', desc:'كلاسيكي بدون ألوان', css:'grayscale(1) contrast(1.08)'},
  {id:'vintage', label:'قديم Vintage', desc:'طابع أفلام قديمة', css:'sepia(0.55) contrast(0.92) brightness(1.02) saturate(0.9)'},
];

function dims(aspect:Settings['aspect'], quality:Settings['quality']){
  const w = quality==='720p'?720:1080;
  if(aspect==='16:9') return {w: Math.round(w*16/9), h:w};
  if(aspect==='9:16') return {w, h: Math.round(w*16/9)};
  return {w, h:w};
}
function fmt(s:number){ if(!isFinite(s)||s<0) s=0; const m=Math.floor(s/60); const sec=Math.floor(s%60); return `${String(m).padStart(2,'0')}:${String(sec).padStart(2,'0')}`; }

export default function App(){
  const [slides, setSlides] = useState<Slide[]>([]);
  const [newTitle, setNewTitle] = useState('لحظة جميلة');
  const [paletteIdx, setPaletteIdx] = useState(0);
  const [settings, setSettings] = useState<Settings>({duration:3, aspect:'16:9', quality:'720p', transition:'fade', speed:0.7, title:'فيديو صوري', subtitle:'صُنع بحب من صورك ولحظاتك', pos:'bottom', textColor:'#ffffff', fontSize:54, filter:'none', watermark:'محرر فيديو صوري', showWatermark:false, muted:false});
  const [playing, setPlaying] = useState(false);
  const [time, setTime] = useState(0);
  const [dragIdx, setDragIdx] = useState<number|null>(null);
  const [projectName, setProjectName] = useState('مشروعي الأول');
  const [saved, setSaved] = useState<any[]>([]);
  const [saveMsg, setSaveMsg] = useState('');
  const [saveError, setSaveError] = useState('');
  const [loadingSaved, setLoadingSaved] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [exportProgress, setExportProgress] = useState(0);
  const [exportedUrl, setExportedUrl] = useState('');
  const [exportedFileName, setExportedFileName] = useState('my-video.webm');
  const [exportedSize, setExportedSize] = useState('');
  const [exportMsg, setExportMsg] = useState('');
  const [exportError, setExportError] = useState('');
  const [exportLog, setExportLog] = useState<string[]>([]);
  const [showAudioFallback, setShowAudioFallback] = useState(false);
  const [showAllText, setShowAllText] = useState(false);

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const timeRef = useRef(0);
  const rafRef = useRef(0);
  const lastRef = useRef(0);
  const exportedUrlRef = useRef('');
  const exportAbortRef = useRef(false);

  const total = slides.length * settings.duration;
  const currentIndex = slides.length ? Math.min(slides.length-1, Math.floor(time / settings.duration)) : 0;

  const pushLog = (msg:string)=> setExportLog(prev=>[...prev.slice(-5), msg]);

  const drawFrame = useCallback((ctx:CanvasRenderingContext2D, W:number, H:number, t:number, s:Settings, list:Slide[])=>{
    ctx.save();
    ctx.fillStyle='#0f071a'; ctx.fillRect(0,0,W,H);
    if(!list.length){
      ctx.fillStyle='#fbf7ff'; ctx.textAlign='center';
      ctx.font=`800 ${Math.round(H*0.07)}px Cairo, sans-serif`;
      ctx.fillText('أضف شريحة لبدء المعاينة', W/2, H/2-10);
      ctx.fillStyle='#c9b8e6'; ctx.font=`500 ${Math.round(H*0.032)}px Cairo, sans-serif`;
      ctx.fillText('استخدم نموذج إضافة شريحة أسفل المعاينة', W/2, H/2+34);
      ctx.restore(); return;
    }
    const idx = Math.min(list.length-1, Math.floor(t / s.duration));
    const local = t - idx*s.duration;
    const transDur = s.transition==='none'?0: Math.min(s.speed, s.duration*0.45);
    const inTrans = idx>0 && local < transDur;
    const p = inTrans ? local/transDur : 1;

    const drawOne = (slide:Slide, alpha:number, dx:number, scale:number)=>{
      ctx.save(); ctx.globalAlpha=Math.max(0,Math.min(1,alpha));
      ctx.translate(W/2+dx, H/2); ctx.scale(scale,scale); ctx.translate(-W/2,-H/2);
      const g = ctx.createLinearGradient(0,0,W,H); g.addColorStop(0,slide.color); g.addColorStop(1,slide.color2);
      ctx.fillStyle=g; ctx.fillRect(-W*0.2,-H*0.2,W*1.4,H*1.4);
      ctx.fillStyle='rgba(255,255,255,0.14)'; ctx.beginPath(); ctx.arc(W*0.86,H*0.16,Math.min(W,H)*0.22,0,Math.PI*2); ctx.fill();
      ctx.fillStyle='rgba(0,0,0,0.12)'; ctx.beginPath(); ctx.arc(W*0.08,H*0.88,Math.min(W,H)*0.18,0,Math.PI*2); ctx.fill();
      ctx.fillStyle='rgba(255,255,255,0.96)'; ctx.textAlign='center'; ctx.textBaseline='middle';
      ctx.font=`900 ${Math.round(Math.min(W,H)*0.11)}px Cairo, sans-serif`;
      const words = slide.title || 'شريحة';
      if(words.length>18){ const a=words.slice(0,18); const b=words.slice(18); ctx.fillText(a, W/2, H/2-22); ctx.font=`800 ${Math.round(Math.min(W,H)*0.07)}px Cairo, sans-serif`; ctx.fillText(b, W/2, H/2+38); }
      else ctx.fillText(words, W/2, H/2);
      ctx.fillStyle='rgba(255,255,255,0.75)'; ctx.font=`600 ${Math.round(Math.min(W,H)*0.035)}px Cairo, sans-serif`;
      ctx.fillText(`شريحة ${list.indexOf(slide)+1} من ${list.length}`, W/2, H/2 + Math.min(W,H)*0.18);
      ctx.restore();
    };

    const filterCss = FILTERS.find(f=>f.id===s.filter)?.css || 'none';
    // @ts-ignore canvas filter
    ctx.filter = filterCss;
    if(s.transition==='fade' && inTrans){ drawOne(list[idx-1], 1-p, 0, 1); drawOne(list[idx], p, 0, 1); }
    else if(s.transition==='slide' && inTrans){ drawOne(list[idx-1], 1, -p*W, 1); drawOne(list[idx], 1, (1-p)*W, 1); }
    else if(s.transition==='zoom' && inTrans){ drawOne(list[idx-1], 1-p, 0, 1+p*0.12); drawOne(list[idx], p, 0, 1.18-p*0.18); }
    else if(s.transition==='zoom'){ drawOne(list[idx], 1, 0, 1 + (local/s.duration)*0.12); }
    else drawOne(list[idx], 1, 0, 1);
    // @ts-ignore
    ctx.filter='none';

    const vg = ctx.createRadialGradient(W/2,H/2,Math.min(W,H)*0.3,W/2,H/2,Math.max(W,H)*0.75);
    vg.addColorStop(0,'rgba(0,0,0,0)'); vg.addColorStop(1,'rgba(0,0,0,0.28)'); ctx.fillStyle=vg; ctx.fillRect(0,0,W,H);

    if(s.title || s.subtitle){
      const pad = H*0.07;
      let y = s.pos==='top'? pad + H*0.06 : s.pos==='center'? H*0.42 : H - pad - H*0.14;
      ctx.textAlign='center'; ctx.textBaseline='middle';
      ctx.fillStyle='rgba(0,0,0,0.32)';
      const boxW = Math.min(W*0.88, 900); const boxH = s.subtitle? H*0.20 : H*0.13; const boxX=(W-boxW)/2; const boxY=y-H*0.03;
      ctx.beginPath(); const r=18; ctx.roundRect(boxX, boxY, boxW, boxH, r); ctx.fill();
      ctx.fillStyle=s.textColor; ctx.font=`900 ${Math.round(s.fontSize * (W/1280))}px Cairo, sans-serif`;
      if(s.title) ctx.fillText(s.title, W/2, y + H*0.035);
      if(s.subtitle){ ctx.fillStyle=s.textColor; ctx.globalAlpha=0.92; ctx.font=`600 ${Math.round(s.fontSize*0.45*(W/1280))}px Cairo, sans-serif`; ctx.fillText(s.subtitle, W/2, y + H*0.11); ctx.globalAlpha=1; }
    }
    if(s.showWatermark && s.watermark){
      ctx.fillStyle='rgba(255,255,255,0.85)'; ctx.textAlign='right'; ctx.font=`700 ${Math.round(H*0.026)}px Cairo, sans-serif`;
      ctx.fillText(s.watermark, W-18, H-16);
    }
    ctx.restore();
  },[]);

  useEffect(()=>{
    const canvas = canvasRef.current; if(!canvas) return;
    const {w,h} = dims(settings.aspect, settings.quality);
    if(canvas.width!==w) canvas.width=w;
    if(canvas.height!==h) canvas.height=h;
    const ctx = canvas.getContext('2d'); if(!ctx) return;
    drawFrame(ctx,w,h,timeRef.current,settings,slides);
  },[settings, slides, time, drawFrame]);

  useEffect(()=>{
    if(!playing) return;
    lastRef.current = performance.now();
    const tick = (now:number)=>{
      const dt=(now-lastRef.current)/1000; lastRef.current=now;
      timeRef.current += dt;
      if(timeRef.current>=total){ timeRef.current=total; setTime(total); setPlaying(false); return; }
      setTime(timeRef.current);
      rafRef.current=requestAnimationFrame(tick);
    };
    rafRef.current=requestAnimationFrame(tick);
    return ()=>cancelAnimationFrame(rafRef.current);
  },[playing, total]);

  // Revoke old blob URL only when a new one replaces it / on unmount
  useEffect(()=>()=>{ if(exportedUrlRef.current) URL.revokeObjectURL(exportedUrlRef.current); },[]);

  const togglePlay = ()=>{
    if(!slides.length) return;
    if(time>=total){ timeRef.current=0; setTime(0); }
    setPlaying(v=>!v);
  };
  const restart = ()=>{ timeRef.current=0; setTime(0); setPlaying(true); };
  const seek = (v:number)=>{ timeRef.current=v; setTime(v); };

  const addSlide = ()=>{
    const p = PALETTES[paletteIdx];
    const slide:Slide={id: Math.random().toString(36).slice(2)+Date.now(), title:newTitle.trim()||'شريحة جديدة', color:p.color, color2:p.color2, pattern:p.label};
    setSlides(prev=>[...prev, slide]); setSaveMsg(''); setNewTitle(''); setPlaying(false);
  };
  const removeSlide = (id:string)=> setSlides(prev=>prev.filter(s=>s.id!==id));
  const moveSlide = (from:number,to:number)=>{ if(from===to) return; setSlides(prev=>{ const a=[...prev]; const [it]=a.splice(from,1); a.splice(to,0,it); return a; }); };

  async function api(action:string, args:any){
    const res = await fetch("actions",{method:'POST', headers:{'content-type':'application/json'}, body:JSON.stringify({action, args})});
    const j = await res.json().catch(()=>({})); if(!res.ok || j.error) throw new Error(j.error||'تعذّر الاتصال بالحفظ'); return j.data;
  }
  const reloadSaved = useCallback(async()=>{
    setLoadingSaved(true);
    try{ const d:any = await api('records.list',{collection:'video_projects'}); setSaved(d?.records||[]); setSaveError(''); }
    catch{ setSaveError('الحفظ غير متاح في هذه المعاينة، لكن المحرر يعمل بالكامل في متصفحك.'); }
    finally{ setLoadingSaved(false); }
  },[]);
  useEffect(()=>{ reloadSaved(); },[reloadSaved]);

  const saveProject = async()=>{
    setSaveMsg(''); setSaveError('');
    try{
      await api('records.create',{collection:'video_projects', value:{name:projectName, slides, settings, savedAt:new Date().toISOString()}, idempotency_key: crypto.randomUUID()});
      setSaveMsg('تم حفظ المشروع بنجاح. ستجده في قائمة المشاريع المحفوظة.'); await reloadSaved();
    }catch(e:any){ setSaveError(e.message||'تعذّر الحفظ'); }
  };
  const loadProject = (rec:any)=>{
    const v=rec.value||{}; setSlides(v.slides||[]); if(v.settings) setSettings(v.settings); setProjectName(v.name||'مشروع محفوظ'); setTime(0); timeRef.current=0; setPlaying(false); setSaveMsg('تم تحميل المشروع. يمكنك تعديله ثم حفظه من جديد.'); window.scrollTo({top:0, behavior:'smooth'});
  };
  const deleteProject = async(id:string)=>{
    try{ await api('records.delete',{collection:'video_projects', id}); await reloadSaved(); setSaveMsg('تم حذف المشروع.'); }catch(e:any){ setSaveError('تعذّر الحذف'); }
  };

  const exportVideo = async (withAudio:boolean)=>{
    if(!slides.length){
      const m='أضف شريحة واحدة على الأقل قبل التصدير — لم ترفع صور / لم تضف شرائح بعد.';
      setExportError(m); setExportMsg(''); pushLog(m); return;
    }
    if(exporting) return;
    exportAbortRef.current=false;
    setExporting(true); setExportProgress(0);
    setExportError(''); setExportMsg('جاري التصدير... لا تغلق الصفحة');
    setShowAudioFallback(false);
    setExportLog([]);
    pushLog(`بدأ التصدير — ${slides.length} شريحة × ${settings.duration} ث = ${fmt(total)}`);
    if(withAudio && settings.muted) pushLog('الصوت مكتوم في الإعدادات — سيُصدَّر الفيديو بدون مسار صوتي مسموع.');
    if(!withAudio) pushLog('وضع التصدير: بدون صوت.');
    setPlaying(false);

    let audioCtx: AudioContext | null = null;
    let dest: MediaStreamAudioDestinationNode | null = null;
    let rafId = 0; let iv: ReturnType<typeof setInterval> | null = null; let stopTimer: ReturnType<typeof setTimeout> | null = null;
    let recorder: MediaRecorder | null = null;

    const cleanup = ()=>{
      if(rafId) cancelAnimationFrame(rafId);
      if(iv) clearInterval(iv);
      if(stopTimer) clearTimeout(stopTimer);
      if(audioCtx){ try{ audioCtx.close(); }catch{} audioCtx=null; }
    };

    try{
      const {w,h}=dims(settings.aspect, settings.quality);
      const off=document.createElement('canvas'); off.width=w; off.height=h;
      const ctx=off.getContext('2d');
      if(!ctx) throw new Error('المتصفح لا يدعم التصدير من Canvas.');
      // رسم الإطار الأول فورًا حتى لا يبدأ التسجيل على شاشة فارغة
      drawFrame(ctx,w,h,0,settings,slides);

      const captureFn = (off as any).captureStream;
      if(typeof captureFn !== 'function') throw new Error('المتصفح لا يدعم التقاط الفيديو من Canvas (captureStream). جرّب متصفح Chrome حديث.');
      const videoStream: MediaStream = captureFn.call(off, 30);
      if(!videoStream || videoStream.getVideoTracks().length===0) throw new Error('تعذّر التقاط مسار الفيديو من Canvas.');

      let combinedStream: MediaStream = videoStream;
      if(withAudio && !settings.muted){
        try{
          const AC = (window as any).AudioContext || (window as any).webkitAudioContext;
          if(!AC) throw new Error('AudioContext غير متاح');
          audioCtx = new AC() as AudioContext;
          if(audioCtx.state==='suspended'){ try{ await audioCtx.resume(); }catch{} }
          dest = audioCtx.createMediaStreamDestination();
          // لا يوجد ملف صوت مرفوع في هذه النسخة، لذلك نُنشئ وجهة الصوت ونزامنها مع التسجيل.
          // عند توفر مصدر صوتي يُوصَّل هنا قبل بدء التسجيل. بدون مصدر، يُصدَّر الفيديو بدون صوت ولا يفشل.
          pushLog('تم تجهيز مسار الصوت (AudioContext + MediaStreamDestination) ومزامنته مع بدء التسجيل.');
          const audioTracks = dest.stream.getAudioTracks();
          combinedStream = new MediaStream([...videoStream.getVideoTracks(), ...audioTracks]);
        }catch(ae:any){
          pushLog('تعذّر تجهيز الصوت — سيُكمل التصدير بدون صوت: '+(ae?.message||'خطأ صوتي'));
          combinedStream = videoStream;
        }
      } else if(withAudio){
        pushLog('تم تخطي مسار الصوت لأن الصوت مكتوم.');
      }

      if(!(window as any).MediaRecorder) throw new Error('المتصفح لا يدعم تسجيل الفيديو (MediaRecorder). جرّب متصفح Chrome أو Edge حديث.');

      const candidates = ['video/webm;codecs=vp9,opus','video/webm;codecs=vp8,opus','video/webm','video/mp4'];
      let mime = '';
      for(const c of candidates){ try{ if((window as any).MediaRecorder.isTypeSupported(c)){ mime=c; break; } }catch{} }
      if(!mime) throw new Error('المتصفح لا يدعم أي صيغة تسجيل متاحة (WebM / MP4). حدّث متصفحك أو جرّب متصفحًا آخر.');
      pushLog(`صيغة التسجيل المختارة: ${mime}`);
      setExportedFileName(mime.includes('mp4') ? 'my-video.mp4' : 'my-video.webm');

      const chunks: Blob[] = [];
      try{ recorder = new MediaRecorder(combinedStream, mime ? {mimeType:mime, videoBitsPerSecond: 5_000_000} : undefined); }
      catch{ throw new Error('تعذّر بدء التسجيل في هذا المتصفح. جرّب خيار «تصدير بدون صوت».'); }
      recorder.ondataavailable = (e)=>{ if(e.data && e.data.size) chunks.push(e.data); };
      recorder.onerror = (e:any)=>{ pushLog('خطأ أثناء التسجيل: '+(e?.message||'MediaRecorder error')); };
      const stopped = new Promise<void>((resolve, reject)=>{
        if(!recorder) return reject(new Error('لم يبدأ المسجّل'));
        recorder.onstop = ()=>resolve();
        recorder.onerror = ()=>reject(new Error('حدث خطأ أثناء التسجيل. جرّب «تصدير بدون صوت».'));
      });

      const totalMs = Math.max(500, total*1000);
      const start = performance.now();
      iv = setInterval(()=>{ const el=performance.now()-start; setExportProgress(Math.min(99, Math.round(el/totalMs*100))); },150);

      recorder.start(200);
      pushLog('بدأ التسجيل...');

      // حلقة الرسم — تتوقف حتمًا بعد totalMs عبر setTimeout
      await new Promise<void>((resolve)=>{
        let last=performance.now(); let t=0; let done=false;
        const finish=()=>{ if(done) return; done=true; resolve(); };
        const step=(now:number)=>{
          const dt=(now-last)/1000; last=now; t+=dt;
          drawFrame(ctx,w,h,Math.min(t,total),settings,slides);
          if(t<total && !exportAbortRef.current) rafId=requestAnimationFrame(step); else finish();
        };
        rafId=requestAnimationFrame(step);
        // إيقاف حتمي بعد المدة الكاملة — يضمن إيقاف MediaRecorder حتى للفيديو القصير (شريحة واحدة)
        stopTimer=setTimeout(()=>{ if(rafId) cancelAnimationFrame(rafId); finish(); }, totalMs+250);
      });

      setExportProgress(100);
      if(recorder.state!=='inactive'){ try{ recorder.stop(); }catch{} }
      await stopped;
      cleanup();
      if(exportAbortRef.current) throw new Error('تم إلغاء التصدير.');

      if(!chunks.length) throw new Error('اكتمل التسجيل لكن لم يتم إنشاء أي بيانات فيديو. جرّب تقليل الجودة إلى 720p أو «تصدير بدون صوت».');
      const blob = new Blob(chunks, {type: recorder.mimeType || mime || 'video/webm'});
      if(blob.size===0) throw new Error('الملف الناتج فارغ. جرّب «تصدير بدون صوت» أو متصفحًا آخر.');
      const url = URL.createObjectURL(blob);
      // لا نلغي الرابط القديم إلا بعد إنشاء الجديد، حتى يبقى رابط التحميل صالحًا
      const old = exportedUrlRef.current;
      exportedUrlRef.current = url;
      setExportedUrl(url);
      setExportedSize(`${(blob.size/1024/1024).toFixed(2)} م.ب`);
      if(old) URL.revokeObjectURL(old);
      setExportMsg(`تم إنشاء الفيديو بنجاح — المدة ${fmt(total)} • الصيغة ${blob.type||'webm'} • الحجم ${(blob.size/1024/1024).toFixed(2)} م.ب`);
      setExportError(''); setExporting(false); setShowAudioFallback(false);
      pushLog('اكتمل التصدير — اضغط «تحميل الفيديو» لتنزيل الملف.');
    }catch(e:any){
      cleanup();
      const msg = e?.message || 'تعذّر التصدير. حاول مرة أخرى.';
      setExportError(msg);
      setExportMsg('');
      pushLog('فشل التصدير: '+msg);
      setExporting(false);
      if(withAudio) setShowAudioFallback(true);
    }
  };

  const set = (patch:Partial<Settings>)=> setSettings(s=>({...s,...patch}));

  return (
    <div dir="rtl" lang="ar" data-safe-area-inset-root style={{boxSizing:'border-box', paddingTop:'var(--safe-area-inset-top)', minHeight:'100vh', background:'radial-gradient(900px 420px at 85% -10%, rgba(236,72,153,.28), transparent), radial-gradient(800px 420px at 10% 0%, rgba(168,85,247,.32), transparent), var(--bg)'}} className="text-[var(--text)] overflow-x-clip">
      <header data-safe-area-sticky-top style={{top:'var(--safe-area-inset-top)'}} className="sticky z-20 border-b border-[var(--line)] bg-[#140a26]/90 backdrop-blur">
        <div className="max-w-7xl mx-auto px-4 py-4 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-purple-500 to-pink-500 grid place-items-center font-black text-xl shrink-0">🎬</div>
            <div className="min-w-0"><h1 className="text-xl sm:text-2xl font-black leading-tight">محرر فيديو صوري</h1><p className="text-xs sm:text-sm text-[var(--muted)]">حوّل شرائحك إلى فيديو جميل — بالكامل داخل متصفحك</p></div>
          </div>
          <div className="flex items-center gap-2 text-xs font-bold"><span className="hidden sm:inline px-3 py-1.5 rounded-full bg-white/10">بدون سيرفر</span><span className="px-3 py-1.5 rounded-full bg-gradient-to-l from-purple-500 to-pink-500">معاينة حية + تصدير</span></div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 pt-5">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          {[{n:1,t:'ارفع / أنشئ شرائحك',d:'أضف شرائحك ورتّبها بالسحب'},{n:2,t:'أضف الصوت',d:'رفع الصوت غير متاح بعد'},{n:3,t:'خصّص الفيديو',d:'نص، فلتر، انتقال، أبعاد'},{n:4,t:'صدّر الفيديو',d:'WebM بجودة 720p / 1080p'}].map(s=>(
            <div key={s.n} className="rounded-2xl border border-[var(--line)] bg-[var(--surface)] p-3 sm:p-4 flex gap-3"><span className="w-9 h-9 shrink-0 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 grid place-items-center font-black">{s.n}</span><div className="min-w-0"><p className="font-extrabold text-sm sm:text-base leading-snug">{s.t}</p><p className="text-xs text-[var(--muted)] mt-0.5 leading-relaxed">{s.d}</p></div></div>
          ))}
        </div>
        <div className="mt-4 rounded-2xl border border-amber-400/40 bg-amber-400/10 p-3 sm:p-4 flex gap-3 items-start"><AlertCircle className="shrink-0 text-amber-300 mt-0.5" size={20}/><p className="text-sm leading-relaxed [overflow-wrap:anywhere]"><b>ملاحظة مهمة:</b> رفع الصور وملفات الصوت غير متاح بعد في هذه النسخة، لذلك أنشئ شرائحك من هنا مباشرة (عنوان + لون) وسيعمل التصدير والمعاينة بها. عند توفر الرفع سنفعّله دون أن تفقد مشاريعك المحفوظة.</p></div>
      </div>

      <main className="max-w-7xl mx-auto px-4 py-5 grid lg:grid-cols-[1fr_380px] gap-5 items-start">
        <section className="space-y-5 min-w-0">
          <div className="rounded-3xl border border-[var(--line)] bg-[var(--surface)] overflow-hidden">
            <div className="p-4 flex flex-wrap items-center justify-between gap-3"><div><h2 className="font-black text-lg flex items-center gap-2"><Film size={20} className="text-pink-400"/> معاينة حية</h2><p className="text-xs text-[var(--muted)] mt-1">شاهد الانتقال والنص والفلتر قبل التصدير.</p></div><span className="text-xs font-bold px-3 py-1.5 rounded-full bg-white/10">{slides.length?`الشريحة ${currentIndex+1} من ${slides.length}`:'لا توجد شرائح'}</span></div>
            <div className="px-4 pb-4">
              <div className="rounded-2xl overflow-hidden bg-black border border-black/40 shadow-2xl"><canvas ref={canvasRef} className="w-full block" style={{aspectRatio: settings.aspect==='16:9'?'16 / 9': settings.aspect==='9:16'?'9 / 16':'1 / 1'}} aria-label="معاينة الفيديو"/></div>
              <div className="mt-4 flex items-center gap-3">
                <button onClick={togglePlay} disabled={!slides.length} className="w-11 h-11 shrink-0 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 grid place-items-center disabled:opacity-40" aria-label={playing?'إيقاف':'تشغيل'}>{playing?<Pause size={20}/>:<Play size={20} className="ms-0.5"/>}</button>
                <button onClick={restart} disabled={!slides.length} className="w-10 h-10 shrink-0 rounded-full bg-white/10 grid place-items-center disabled:opacity-40" aria-label="إعادة من البداية"><RotateCcw size={18}/></button>
                <input type="range" min={0} max={total||0} step={0.1} value={time} onChange={e=>seek(Number(e.target.value))} className="flex-1 min-w-0" aria-label="شريط تقدم الفيديو"/>
                <span className="text-xs sm:text-sm font-bold whitespace-nowrap tabular-nums">{fmt(time)} / {fmt(total)}</span>
              </div>
              <div className="mt-3 flex flex-wrap gap-2">{slides.map((s,i)=>(<button key={s.id} onClick={()=>seek(i*settings.duration)} className={`px-3 py-1.5 rounded-full text-xs font-bold border ${i===currentIndex?'bg-white text-black border-white':'bg-white/5 border-white/10'}`}>{i+1} • {s.title}</button>))}</div>
              {!slides.length && <div className="mt-4 rounded-2xl bg-purple-500/10 border border-purple-400/30 p-4 text-center"><p className="font-bold">لم تضف أي شريحة بعد ✨</p><p className="text-sm text-[var(--muted)] mt-1">اكتب عنوان شريحة واختر لونها ثم اضغط «إضافة شريحة» — ستظهر هنا فورًا.</p></div>}
            </div>
          </div>

          <div className="rounded-3xl border border-[var(--line)] bg-[var(--surface)] p-4 sm:p-5">
            <h3 className="font-black text-lg flex items-center gap-2"><Images size={20} className="text-purple-300"/> ١ — شرائحك</h3>
            <p className="text-xs text-[var(--muted)] mt-1">أضف شريحة بعنوان ولون، ثم اسحبها لإعادة ترتيبها. اسحب المقبض ⋮⋮ لتغيير الترتيب.</p>
            <div className="mt-4 grid sm:grid-cols-[1fr_auto] gap-3">
              <label className="block"><span className="text-xs font-bold text-[var(--muted)]">عنوان الشريحة</span><input value={newTitle} onChange={e=>setNewTitle(e.target.value)} className="mt-1 w-full rounded-xl bg-[var(--surface2)] border border-[var(--line)] px-3 py-2.5 text-sm [overflow-wrap:anywhere]" placeholder="مثال: يوم على البحر"/></label>
              <button onClick={addSlide} className="rounded-xl bg-gradient-to-l from-purple-500 to-pink-500 px-5 py-2.5 font-black flex items-center justify-center gap-2"><Plus size={18}/> إضافة شريحة</button>
            </div>
            <div className="mt-3 flex flex-wrap gap-2" role="radiogroup" aria-label="اختر لون الشريحة">{PALETTES.map((p,i)=>(<button key={p.label} onClick={()=>setPaletteIdx(i)} className={`h-10 flex-1 min-w-[92px] rounded-xl text-[11px] font-bold border-2 ${paletteIdx===i?'border-white':'border-transparent'}`} style={{background:`linear-gradient(135deg, ${p.color}, ${p.color2})`}}>{p.label}</button>))}</div>
            {slides.length>0 && <div className="mt-4 space-y-2">{slides.map((s,i)=>(
              <div key={s.id} draggable onDragStart={()=>setDragIdx(i)} onDragOver={e=>e.preventDefault()} onDrop={()=>{ if(dragIdx!==null) moveSlide(dragIdx,i); setDragIdx(null); }} className="flex items-center gap-2 rounded-2xl border border-[var(--line)] bg-[var(--surface2)] p-2">
                <span className="cursor-grab text-[var(--muted)]" title="اسحب للترتيب"><GripVertical size={18}/></span>
                <span className="w-12 h-10 rounded-xl shrink-0 grid place-items-center text-[11px] font-black" style={{background:`linear-gradient(135deg, ${s.color}, ${s.color2})`}}>{i+1}</span>
                <span className="flex-1 min-w-0 font-bold text-sm [overflow-wrap:anywhere]">{s.title}</span>
                <span className="hidden sm:inline text-[11px] text-[var(--muted)]">{s.pattern}</span>
                <button onClick={()=>removeSlide(s.id)} className="p-2 rounded-lg bg-red-500/15 text-red-300 hover:bg-red-500/30" aria-label={`حذف ${s.title}`}><Trash2 size={16}/></button>
              </div>
            ))}
            <div className="flex justify-between mt-3"><span className="text-xs text-[var(--muted)]">المدة الكلية: <b className="text-white">{fmt(total)}</b> • {slides.length} شرائح</span><button onClick={()=>{setSlides([]); setTime(0); timeRef.current=0; setPlaying(false);}} className="text-xs font-bold text-red-300">مسح الكل</button></div>
            </div>}
          </div>

          <div className="rounded-3xl border border-[var(--line)] bg-[var(--surface)] p-4 sm:p-5">
            <h3 className="font-black text-lg flex items-center gap-2"><Music size={20} className="text-pink-400"/> ٢ — الصوت</h3>
            <p className="text-sm text-[var(--muted)] mt-1 leading-relaxed">رفع ملف صوتي (MP3 / WAV) غير متاح بعد، لذلك يُصدَّر الفيديو حاليًا بدون مسار صوتي مسموع. يمكنك كتم/تشغيل الصوت عند توفره من هنا.</p>
            <div className="mt-4 flex flex-wrap items-center gap-3"><button onClick={()=>set({muted:!settings.muted})} className="px-4 py-2.5 rounded-xl bg-white/10 font-bold flex items-center gap-2">{settings.muted?<VolumeX size={18}/>:<Volume2 size={18}/>} {settings.muted?'الصوت مكتوم':'الصوت مفعّل'}</button><span className="text-xs text-[var(--muted)]">الحالة تُحفظ مع المشروع.</span></div>
          </div>

          <div className="rounded-3xl border border-[var(--line)] bg-gradient-to-br from-purple-600/25 to-pink-600/20 p-4 sm:p-5">
            <h3 className="font-black text-lg flex items-center gap-2"><Download size={20}/> ٤ — تصدير الفيديو</h3>
            <p className="text-xs text-[var(--muted)] mt-1">يُعاد تشغيل الفيديو في الخلفية وتسجيله مباشرة من Canvas. ابقَ في الصفحة حتى يكتمل التصدير.</p>

            <div className="mt-4 grid sm:grid-cols-2 gap-3">
              <button onClick={()=>exportVideo(true)} disabled={exporting||!slides.length} className="w-full py-3.5 rounded-2xl bg-gradient-to-l from-purple-500 to-pink-500 font-black text-base disabled:opacity-40 disabled:cursor-not-allowed">{exporting?`جارٍ التصدير… ${exportProgress}%`:'تصدير الفيديو'}</button>
              <button onClick={()=>exportVideo(false)} disabled={exporting||!slides.length} className="w-full py-3.5 rounded-2xl bg-white/10 border border-white/20 font-black text-base disabled:opacity-40 disabled:cursor-not-allowed">تصدير بدون صوت</button>
            </div>

            {exporting && (
              <div className="mt-4 rounded-2xl border border-white/20 bg-black/30 p-4" role="status" aria-live="polite">
                <p className="font-black flex items-center gap-2"><span className="inline-block w-3 h-3 rounded-full bg-emerald-400 animate-pulse"/> جاري التصدير... لا تغلق الصفحة</p>
                <p className="text-xs text-[var(--muted)] mt-1">المدة الكلية: {fmt(total)} — يجري تسجيل الفيديو لحظة بلحظة.</p>
                <div className="mt-3 h-3 rounded-full bg-black/40 overflow-hidden"><div className="h-full bg-gradient-to-l from-purple-400 to-pink-400 transition-all" style={{width:`${exportProgress}%`}}/></div>
                <p className="mt-2 text-xs font-bold tabular-nums">{exportProgress}% مكتمل</p>
              </div>
            )}

            {exportError && (
              <div className="mt-4 rounded-2xl border border-red-400/50 bg-red-500/10 p-4" role="alert">
                <p className="font-black text-red-200 flex gap-2 items-start"><AlertTriangle size={18} className="shrink-0 mt-0.5"/> <span className="[overflow-wrap:anywhere]">{exportError}</span></p>
                {showAudioFallback && (
                  <button onClick={()=>exportVideo(false)} disabled={exporting} className="mt-3 w-full py-3 rounded-xl bg-emerald-500 text-white font-black flex items-center justify-center gap-2 disabled:opacity-40"><Download size={18}/> تحميل بدون صوت — جرّب هذا الخيار</button>
                )}
                <button onClick={()=>exportVideo(true)} disabled={exporting} className="mt-2 w-full py-2.5 rounded-xl bg-white/10 font-bold flex items-center justify-center gap-2 disabled:opacity-40"><RefreshCw size={16}/> إعادة المحاولة</button>
              </div>
            )}

            {exportLog.length>0 && (
              <div className="mt-4 rounded-2xl bg-black/25 border border-white/10 p-3">
                <p className="text-xs font-black text-[var(--muted)] mb-2">سجل التصدير:</p>
                <ul className="space-y-1">{exportLog.map((l,i)=>(<li key={i} className="text-xs leading-relaxed [overflow-wrap:anywhere]">• {l}</li>))}</ul>
              </div>
            )}

            {exportMsg && !exporting && <p className="mt-3 text-sm font-bold leading-relaxed [overflow-wrap:anywhere]">{exportMsg}</p>}

            {exportedUrl && !exporting && (
              <div className="mt-4 rounded-3xl border-2 border-emerald-400 bg-emerald-500/10 p-4 sm:p-5 space-y-3">
                <h4 className="text-xl sm:text-2xl font-black text-emerald-300 flex items-center gap-2">✅ الفيديو جاهز</h4>
                <p className="text-sm text-[var(--muted)]">اضغط زر التحميل الأخضر — سيبدأ تنزيل الملف فورًا على جهازك. اسم الملف: <b className="text-white [overflow-wrap:anywhere]">{exportedFileName}</b>{exportedSize?` • ${exportedSize}`:''}</p>
                <video src={exportedUrl} controls playsInline className="w-full rounded-2xl bg-black" />
                <a href={exportedUrl} download={exportedFileName} className="block text-center py-4 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-white font-black text-lg shadow-lg shadow-emerald-500/30">⬇ تحميل الفيديو</a>
                <a href={exportedUrl} download={exportedFileName} className="block text-center py-3 rounded-2xl bg-white text-black font-black">تحميل مرة أخرى</a>
                <p className="text-xs text-[var(--muted)] text-center">إذا لم يبدأ التحميل، اضغط مطولًا على زر التحميل واختر «تنزيل». إذا لم يتوفر MP4 في متصفحك، يُصدَّر تلقائيًا بصيغة WebM المتاحة.</p>
              </div>
            )}
          </div>
        </section>

        <aside className="space-y-5 lg:sticky lg:top-24">
          <div className="rounded-3xl border border-[var(--line)] bg-[var(--surface)] p-4 sm:p-5">
            <h3 className="font-black text-lg flex items-center gap-2"><SlidersHorizontal size={20} className="text-purple-300"/> ٣ — خصّص الفيديو</h3>
            <div className="mt-4 space-y-4">
              <div><div className="flex justify-between text-sm font-bold"><span>مدة كل شريحة</span><span>{settings.duration} ثوانٍ</span></div><input type="range" min={1} max={10} step={1} value={settings.duration} onChange={e=>set({duration:Number(e.target.value)})} className="w-full mt-2"/><p className="text-[11px] text-[var(--muted)]">من ١ إلى ١٠ ثوانٍ — الافتراضي ٣ ثوانٍ.</p></div>
              <div><label className="text-sm font-bold">أبعاد الفيديو</label><div className="grid grid-cols-3 gap-2 mt-2">{(['16:9','9:16','1:1'] as const).map(a=>(<button key={a} onClick={()=>set({aspect:a})} className={`py-2.5 rounded-xl font-bold border ${settings.aspect===a?'bg-white text-black border-white':'bg-white/5 border-white/10'}`}>{a}</button>))}</div><p className="text-[11px] text-[var(--muted)] mt-1">16:9 ليوتيوب • 9:16 لريلز وتيك توك • 1:1 لإنستغرام.</p></div>
              <div><label className="text-sm font-bold">الجودة</label><div className="grid grid-cols-2 gap-2 mt-2">{(['720p','1080p'] as const).map(q=>(<button key={q} onClick={()=>set({quality:q})} className={`py-2.5 rounded-xl font-bold border ${settings.quality===q?'bg-white text-black border-white':'bg-white/5 border-white/10'}`}>{q}</button>))}</div></div>
              <div><label className="text-sm font-bold">نوع الانتقال</label><div className="grid grid-cols-2 gap-2 mt-2">{([['fade','تلاشي Fade'],['slide','انزلاق Slide'],['zoom','تكبير Zoom'],['none','بدون']] as const).map(([v,l])=>(<button key={v} onClick={()=>set({transition:v})} className={`py-2.5 rounded-xl font-bold border text-sm ${settings.transition===v?'bg-white text-black border-white':'bg-white/5 border-white/10'}`}>{l}</button>))}</div></div>
              <div><div className="flex justify-between text-sm font-bold"><span>سرعة الانتقال</span><span>{settings.speed.toFixed(1)} ث</span></div><input type="range" min={0.2} max={1.5} step={0.1} value={settings.speed} onChange={e=>set({speed:Number(e.target.value)})} className="w-full mt-2"/></div>
            </div>
          </div>

          <div className="rounded-3xl border border-[var(--line)] bg-[var(--surface)] p-4 sm:p-5">
            <h3 className="font-black flex items-center gap-2"><Type size={20} className="text-pink-400"/> النص على الفيديو</h3>
            <div className="mt-3 space-y-3">
              <label className="block text-xs font-bold text-[var(--muted)]">العنوان<input value={settings.title} onChange={e=>set({title:e.target.value})} className="mt-1 w-full rounded-xl bg-[var(--surface2)] border border-[var(--line)] px-3 py-2.5 text-sm [overflow-wrap:anywhere]"/></label>
              <label className="block text-xs font-bold text-[var(--muted)]">النص الفرعي<input value={settings.subtitle} onChange={e=>set({subtitle:e.target.value})} className="mt-1 w-full rounded-xl bg-[var(--surface2)] border border-[var(--line)] px-3 py-2.5 text-sm [overflow-wrap:anywhere]"/></label>
              <div className="grid grid-cols-2 gap-3"><label className="block text-xs font-bold text-[var(--muted)]">موضع النص<div className="flex gap-1 mt-1">{([['top','أعلى'],['center','وسط'],['bottom','أسفل']] as const).map(([v,l])=>(<button key={v} onClick={()=>set({pos:v})} className={`flex-1 py-2 rounded-lg text-xs font-bold border ${settings.pos===v?'bg-white text-black':'bg-white/5'}`}>{l}</button>))}</div></label><label className="block text-xs font-bold text-[var(--muted)]">لون النص<input type="color" value={settings.textColor} onChange={e=>set({textColor:e.target.value})} className="mt-1 w-full h-10 rounded-lg bg-white/5 border border-[var(--line)]"/></label></div>
              <div><div className="flex justify-between text-xs font-bold text-[var(--muted)]"><span>حجم الخط</span><span>{settings.fontSize}px</span></div><input type="range" min={28} max={90} step={2} value={settings.fontSize} onChange={e=>set({fontSize:Number(e.target.value)})} className="w-full"/></div>
            </div>
          </div>

          <div className="rounded-3xl border border-[var(--line)] bg-[var(--surface)] p-4 sm:p-5">
            <h3 className="font-black flex items-center gap-2"><Wand2 size={18} className="text-purple-300"/> الفلاتر والعلامة المائية</h3>
            <div className="grid grid-cols-2 gap-2 mt-3">{FILTERS.map(f=>(<button key={f.id} onClick={()=>set({filter:f.id})} className={`text-start p-3 rounded-2xl border ${settings.filter===f.id?'border-white bg-white/10':'border-white/10 bg-white/5'}`}><span className="font-bold text-sm block">{f.label}</span><span className="text-[11px] text-[var(--muted)]">{f.desc}</span></button>))}</div>
            <label className="flex items-center gap-2 mt-4 text-sm font-bold"><input type="checkbox" checked={settings.showWatermark} onChange={e=>set({showWatermark:e.target.checked})} className="w-4 h-4 accent-purple-500"/> إظهار علامة مائية نصية</label>
            {settings.showWatermark && <input value={settings.watermark} onChange={e=>set({watermark:e.target.value})} className="mt-2 w-full rounded-xl bg-[var(--surface2)] border border-[var(--line)] px-3 py-2.5 text-sm [overflow-wrap:anywhere]" placeholder="مثال: © اسمي"/>}
          </div>

          <div className="rounded-3xl border border-[var(--line)] bg-[var(--surface)] p-4 sm:p-5">
            <h3 className="font-black flex items-center gap-2"><FolderOpen size={18} className="text-pink-300"/> احفظ مشروعك</h3>
            <p className="text-xs text-[var(--muted)] mt-1 leading-relaxed">يُحفظ اسم المشروع وشرائحك وإعداداتك، لتعود إليها لاحقًا.</p>
            <label className="block mt-3 text-xs font-bold text-[var(--muted)]">اسم المشروع<input value={projectName} onChange={e=>setProjectName(e.target.value)} className="mt-1 w-full rounded-xl bg-[var(--surface2)] border border-[var(--line)] px-3 py-2.5 text-sm [overflow-wrap:anywhere]"/></label>
            <button onClick={saveProject} className="mt-3 w-full py-3 rounded-2xl bg-white text-black font-black flex items-center justify-center gap-2"><Save size={18}/> حفظ المشروع</button>
            {saveMsg && <p className="mt-2 text-xs font-bold text-emerald-300 flex gap-1"><Check size={15} className="shrink-0"/>{saveMsg}</p>}
            {saveError && <p className="mt-2 text-xs text-amber-200 leading-relaxed">{saveError}</p>}
            <div className="mt-4 space-y-2">
              <div className="flex justify-between items-center"><span className="text-sm font-bold">المشاريع المحفوظة</span><button onClick={reloadSaved} className="text-xs font-bold text-purple-300">{loadingSaved?'جارٍ التحميل…':'تحديث'}</button></div>
              {saved.length===0 && <p className="text-xs text-[var(--muted)]">لا توجد مشاريع محفوظة بعد.</p>}
              {saved.map((r:any)=>(<div key={r.id} className="flex items-center gap-2 rounded-xl bg-white/5 border border-white/10 p-2"><div className="flex-1 min-w-0"><p className="text-sm font-bold truncate [overflow-wrap:anywhere]">{r.value?.name||'مشروع'}</p><p className="text-[11px] text-[var(--muted)]">{(r.value?.slides||[]).length} شرائح • {fmt((r.value?.slides||[]).length*(r.value?.settings?.duration||3))}</p></div><button onClick={()=>loadProject(r)} className="px-3 py-1.5 rounded-lg bg-white text-black text-xs font-black">فتح</button><button onClick={()=>deleteProject(r.id)} className="p-2 rounded-lg bg-red-500/15 text-red-300" aria-label="حذف المشروع"><X size={15}/></button></div>))}
            </div>
            <button onClick={()=>setShowAllText(v=>!v)} className="mt-4 text-xs font-bold text-[var(--muted)] underline">{showAllText?'إخفاء الشرح':'كيف يعمل المحرر؟'}</button>
            {showAllText && <p className="mt-2 text-xs leading-relaxed text-[var(--muted)] [overflow-wrap:anywhere]">أنشئ شرائح، خصّص النص والفلتر والانتقال، شغّل المعاينة للتأكد من النتيجة، ثم صدّر. التصدير يسجّل Canvas لحظة بلحظة ويحفظ الفيديو على جهازك. لا تُرفع أي بيانات إلى خادم خارجي أثناء التحرير.</p>}
          </div>
        </aside>
      </main>
      <footer className="max-w-7xl mx-auto px-4 pb-8 text-center text-xs text-[var(--muted)] flex items-center justify-center gap-2"><Clock size={14}/> صُمم ليكون سريعًا وواضحًا — جرّب انتقال التكبير مع فلتر دافئ لنتيجة سينمائية.</footer>
    </div>
  );
}
